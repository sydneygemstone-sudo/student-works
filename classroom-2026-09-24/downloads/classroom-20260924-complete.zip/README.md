# 2026-09-24 课堂完整回收包 / Complete classroom archive

电脑需预装 Node.js。在此目录运行 `node serve.mjs`，打开 http://127.0.0.1:8080/classroom-2026-09-24/ 。不要直接双击 HTML 使用 file://，因为页面需要读取 JSON 与游戏素材。

A preinstalled Node.js is required. Run `node serve.mjs` here and open the local address above. Do not open the HTML via file://; JSON and game assets need HTTP.

Martin V1/V2 和旧 Adventure World 是独立单机入口。两条新的三人 3D 候选需要分别运行服务器；完整运行包在 classroom-2026-09-24/downloads，含 ws 与本地素材，但不含 Node 安装器。运行说明见各包 README。

Martin V1/V2 and the old Adventure World have independent solo entries. The two new 3D candidates require their own servers; their complete runtime ZIPs are under classroom-2026-09-24/downloads, with ws and local assets but no Node installer. Follow their READMEs.

本包已经是完整回收包。离线版页面的“下载完整回收包”按钮改为打开这份说明，避免把包递归放进自己。联机运行包下载仍可用。公开版完整记录与私密课堂原文是不同的档案，私密聊天不包含在本包中。

This is already the complete archive. Its whole-archive button opens this README instead of recursively embedding itself; the two runtime ZIPs remain available. Private raw classroom messages are not included.

版本不是全数通过实机验收：七个快照保留旧版、初稿和修复前文件；课堂讨论和学习内容为标注来源的归纳，不是完整逐字稿。

Not all seven snapshots are accepted device-ready releases; they include baselines, initial writes and pre-fix files. Classroom and learning records are source-labelled summaries, not complete transcripts.
