#!/bin/sh
cd "$(dirname "$0")"
exec node serve.mjs
