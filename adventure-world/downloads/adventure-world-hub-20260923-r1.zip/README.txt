Adventure World — R5 classroom review kit
Extract this ZIP and open START.html on a computer. No Node or online AI is required for play.
解压后用电脑浏览器打开 START.html。不需要 Node 或在线模型。
Report and game saves belong to the browser/origin. They do not automatically transfer between online/offline or devices. Export reports before moving.
报告保存在当前设备；线上与离线、不同浏览器不保证存档互通。移动前请导出。
Exporting a report does not confirm teacher receipt. Physical iPad remains unverified.
Only this course and the required approved R5 styles/gesture guard are included.
