电脑已安装 Node.js 后，在此目录运行 node serve.mjs，再打开 http://127.0.0.1:8080/ 。网页单人试玩无需 Node。
With Node.js installed, run node serve.mjs, then open http://127.0.0.1:8080/. Online solo play needs no Node.
This is already the complete project package.
