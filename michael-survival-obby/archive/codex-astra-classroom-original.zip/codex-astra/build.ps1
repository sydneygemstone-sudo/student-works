$ErrorActionPreference = 'Stop'
Push-Location $PSScriptRoot
try {
  & npm exec --yes --package=esbuild@0.25.12 -- esbuild source/game.js --bundle --minify --format=iife --outfile=development/2026-09-20/mvp-15min/game.bundle.js
  if ($LASTEXITCODE -ne 0) { throw 'Bundling failed' }
  $html = [IO.File]::ReadAllText((Join-Path $PSScriptRoot 'source\shell.html'))
  $bundle = [IO.File]::ReadAllText((Join-Path $PSScriptRoot 'development\2026-09-20\mvp-15min\game.bundle.js'))
  $license = [IO.File]::ReadAllText((Join-Path $PSScriptRoot 'source\vendor\LICENSE'))
  $html = $html.Replace('<!-- GAME_BUNDLE -->', "<!-- Three.js 0.186.0`n$license`n-->`n<!-- GAME_BUNDLE -->")
  [IO.File]::WriteAllText((Join-Path $PSScriptRoot 'release\Bone-Run.html'), $html.Replace('<!-- GAME_BUNDLE -->', ('<script>' + $bundle.Replace('</script','<\/script') + '</script>')), [Text.UTF8Encoding]::new($false))
} finally { Pop-Location }
