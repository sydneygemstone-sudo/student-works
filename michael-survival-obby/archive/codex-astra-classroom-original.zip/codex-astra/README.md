# Bone Run — Michael's 3D Survival Obby

Open **[release/Bone-Run.html](release/Bone-Run.html)** in Chrome, Edge or Safari. It is one self-contained, offline file; no installation, server or account is needed. A browser with WebGL 2 is required. On a touch device, landscape is recommended.

- Move: WASD / arrow keys, or the on-screen direction buttons.
- Jump: Space / JUMP. Keep moving during a jump. Jump near the lime platform edges.
- Escape: collect at least **8 of 12 crystals**, then enter the portal within **5 minutes**.
- Lose: a skeleton catches you, you fall, or the timer reaches zero.
- Esc / pause button pauses both enemies and timer; leaving the tab pauses automatically.
- Run again after a result, or press R. There are no persistent saves to overwrite.

Idea and requirements: Michael's brief supplied by Dean. Implementation, level layout, visual design and engineering checks: Astra in the current task, without subagents. This is the first short MVP, not a record of student playtesting.

Editable source: `source/game.js` and `source/shell.html`; Three.js 0.186.0 is vendored with its MIT license. Run `powershell -File build.ps1` with Node/npm installed to rebuild the standalone release. Building may fetch esbuild 0.25.12; playing never accesses the network.

Engineering record: [development/2026-09-20/mvp-15min](development/2026-09-20/mvp-15min). No public deployment was requested or performed.
