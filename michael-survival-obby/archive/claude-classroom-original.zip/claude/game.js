/* =========================================================================
   Skeleton Run — 3D Survival Obby (MVP)
   核心循环: 跑 → 跳 → 逃 → 收集 → 冲线
   ========================================================================= */
(function () {
'use strict';

// ---------------------------------------------------------------- 可调参数
var CFG = {
  TIME_LIMIT   : 300,    // 5 分钟
  COINS_NEEDED : 8,
  GRAVITY      : -55,
  MOVE_SPEED   : 12,
  AIR_CONTROL  : 0.75,
  JUMP_VEL     : 18,
  COYOTE       : 0.16,   // 离开平台后仍可起跳的宽限
  JUMP_BUFFER  : 0.20,   // 落地前提前按跳的缓冲
  FALL_DEATH_Y : -14,
  SKELE_BASE   : 7.8,    // 骷髅基础速度(玩家 12，跑起来能拉开)
  SKELE_RAMP   : 4.2,    // 随时间线性加压 —— 拖越久越难甩
  BAND_FAR     : 11,     // 超过这个距离就冲刺追回来(保证一直在画面里)
  BAND_NEAR    : 6.5,    // 贴到这么近就略收，给玩家反应空间
  WAKE_TIME    : 2.5,    // 骷髅开局苏醒时间
  CATCH_DIST   : 1.35
};

var params    = new URLSearchParams(location.search);
var AUTO_RUN  = params.get('auto') === '1';   // 自动前进(用于截图/演示)
var FF        = parseFloat(params.get('ff') || '0'); // 开局快进秒数
var BOT       = params.get('bot') === '1';    // 自动试玩机器人(QA: 验证关卡可通关)

// ---------------------------------------------------------------- 渲染基础
var app = document.getElementById('app');
var scene = new THREE.Scene();
scene.background = new THREE.Color(0x0b1020);
scene.fog = new THREE.Fog(0x0b1020, 45, 130);

var camera = new THREE.PerspectiveCamera(65, innerWidth / innerHeight, 0.1, 400);
var renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
renderer.setSize(innerWidth, innerHeight);
app.appendChild(renderer.domElement);

addEventListener('resize', function () {
  camera.aspect = innerWidth / innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(innerWidth, innerHeight);
});

scene.add(new THREE.HemisphereLight(0x9fc4ff, 0x202844, 1.05));
var sun = new THREE.DirectionalLight(0xffffff, 1.15);
sun.position.set(-18, 40, -14);
scene.add(sun);

// 远处的装饰星点，让 3D 纵深更明显
(function starfield() {
  var g = new THREE.BufferGeometry(), n = 500, arr = new Float32Array(n * 3);
  for (var i = 0; i < n; i++) {
    arr[i*3]   = (Math.random() - 0.5) * 300;
    arr[i*3+1] = Math.random() * 90 + 8;
    arr[i*3+2] = Math.random() * 420 - 40;
  }
  g.setAttribute('position', new THREE.BufferAttribute(arr, 3));
  scene.add(new THREE.Points(g, new THREE.PointsMaterial({ color: 0x8fb6ff, size: 0.55, sizeAttenuation: true })));
})();

// 深渊(在死亡高度之下，只做视觉参照)
(function abyss() {
  var m = new THREE.Mesh(new THREE.PlaneGeometry(420, 520),
          new THREE.MeshLambertMaterial({ color: 0x151c38 }));
  m.rotation.x = -Math.PI / 2;
  m.position.set(0, -20, 110);
  scene.add(m);
})();

// 赛道两侧的发光标柱: 跑过多少根 = 跑了多远
(function pylons() {
  var shaft = new THREE.MeshLambertMaterial({ color: 0x27315e });
  var lamp  = new THREE.MeshBasicMaterial({ color: 0x66e0ff });
  for (var z = -10; z < 240; z += 24) {
    for (var s = -1; s <= 1; s += 2) {
      var c = new THREE.Mesh(new THREE.CylinderGeometry(0.45, 0.45, 26, 6), shaft);
      c.position.set(s * 15, -5, z); scene.add(c);
      var b = new THREE.Mesh(new THREE.SphereGeometry(0.8, 10, 10), lamp);
      b.position.set(s * 15, 8.6, z); scene.add(b);
    }
  }
})();

// ---------------------------------------------------------------- 关卡数据
// 每个平台: {x,y,z,w,h,d, move?:{axis,amp,speed,phase}}
var platforms = [], coins = [], sweepers = [], goal = null, LEVEL_END = 0;

var MAT = {
  ground : new THREE.MeshLambertMaterial({ color: 0x3f6fbf }),
  narrow : new THREE.MeshLambertMaterial({ color: 0x6a4fd0 }),
  move   : new THREE.MeshLambertMaterial({ color: 0x27b6a4 }),
  goal   : new THREE.MeshLambertMaterial({ color: 0xffd54a, emissive: 0x6b5200 }),
  bar    : new THREE.MeshLambertMaterial({ color: 0xff5d5d }),
  coin   : new THREE.MeshLambertMaterial({ color: 0x66e0ff, emissive: 0x0a5a70 }),
  bone   : new THREE.MeshLambertMaterial({ color: 0xf1efe4 }),
  eye    : new THREE.MeshBasicMaterial({ color: 0xff2b2b })
};

function addPlatform(x, y, z, w, d, mat, move) {
  var h = 0.9;
  var mesh = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat || MAT.ground);
  mesh.position.set(x, y, z);
  scene.add(mesh);
  var p = { mesh: mesh, x: x, y: y, z: z, w: w, h: h, d: d, baseX: x, baseZ: z, move: move || null, dx: 0, dz: 0 };
  platforms.push(p);
  return p;
}

function addCoin(x, y, z) {
  var m = new THREE.Mesh(new THREE.OctahedronGeometry(0.42), MAT.coin);
  m.position.set(x, y, z);
  scene.add(m);
  var light = new THREE.PointLight(0x66e0ff, 1.1, 7);
  light.position.copy(m.position);
  scene.add(light);
  coins.push({ mesh: m, light: light, got: false });
}

// 旋转横杆: 碰到会被扫飞(不直接死，但可能被扫下悬崖)
function addSweeper(x, y, z, len, speed) {
  var pivot = new THREE.Object3D();
  pivot.position.set(x, y, z);
  scene.add(pivot);
  var bar = new THREE.Mesh(new THREE.BoxGeometry(len, 0.55, 0.55), MAT.bar);
  pivot.add(bar);
  var post = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.14, 1.1, 8), MAT.narrow);
  post.position.y = -0.55; pivot.add(post);
  sweepers.push({ pivot: pivot, len: len, speed: speed, y: y, half: 0.275 });
}

function buildLevel() {
  // 用"上一块平台的前边缘"记账，这样写下的 gap 数字就是真实缺口宽度。
  // 跳跃射程 = MOVE_SPEED * (2*JUMP_VEL/|GRAVITY|) = 12 * 0.655 ≈ 7.85，缺口一律留裕度。
  var edge = 0;
  function place(gap, x, y, w, d, mat, move) {
    var cz = edge + gap + d / 2;
    var p = addPlatform(x, y, cz, w, d, mat, move);
    edge = cz + d / 2;
    return p;
  }

  // --- 1. 起跑安全区(无缺口，先让玩家熟悉手感) ---
  var p0 = place(0, 0, 0, 10, 20);

  // --- 2. 三连缺口: 由易到难，教会"看准落点再起跳" ---
  [4.0, 4.8, 5.5].forEach(function (g) {
    var p = place(g, 0, 0, 8, 8);
    addCoin(p.x, p.y + 1.9, p.z);
  });

  // --- 3. 窄桥 + 两根旋转横杆(第一个真正的压力点) ---
  var bridge = place(4.5, 0, 0, 3.8, 22, MAT.narrow);
  addSweeper(0, bridge.y + 1.0, bridge.z - 5.5, 7, 1.35);
  addSweeper(0, bridge.y + 1.0, bridge.z + 5.5, 7, -1.6);

  // --- 4. 左右交错跳台(加上横向位移，斜跳距离也要够) ---
  var side = 1;
  for (var j = 0; j < 4; j++) {
    var p = place(3.2, side * 2.2, 0.5 + j * 0.4, 5.6, 5);
    if (j % 2 === 0) addCoin(p.x, p.y + 2.2, p.z);
    side *= -1;
  }

  // --- 5. 移动平台: 站上去会被带着走，要等它摆回中间再跳 ---
  place(3.0, 0, 2.4, 7, 6);
  place(3.6, 0, 2.4, 5, 5, MAT.move, { axis: 'x', amp: 5.0, speed: 1.1, phase: 0 });
  var mv2 = place(3.6, 0, 2.4, 5, 5, MAT.move, { axis: 'x', amp: 5.0, speed: 1.3, phase: Math.PI });
  addCoin(mv2.baseX, mv2.y + 1.9, mv2.z);
  var rest = place(3.6, 0, 2.4, 7, 7);
  addCoin(rest.x, rest.y + 1.9, rest.z);

  // --- 6. 横杆长廊(压轴): 三根反向横杆 + 两颗高价值宝石 ---
  var hall = place(4.0, 0, 1.4, 4.2, 26, MAT.narrow);
  addSweeper(0, hall.y + 1.0, hall.z - 8, 8, 1.8);
  addSweeper(0, hall.y + 1.0, hall.z,     8, -2.0);
  addSweeper(0, hall.y + 1.0, hall.z + 8, 8, 2.2);
  addCoin(0, hall.y + 2.0, hall.z - 4);
  addCoin(0, hall.y + 2.0, hall.z + 4);

  // --- 7. 最后两跳，宝石放在必经落点上 ---
  var a = place(4.2, -2.8, 1.4, 5, 5);  addCoin(a.x, a.y + 1.9, a.z);
  var b = place(4.2,  2.8, 1.4, 5, 5);  addCoin(b.x, b.y + 1.9, b.z);

  // --- 8. 终点 ---
  var g = place(4.0, 0, 1.4, 12, 12, MAT.goal);
  goal = { x: g.x, y: g.y, z: g.z, r: 5.2 };
  LEVEL_END = g.z;

  // 终点门框(视觉锚点，远远就能看见)
  var frameMat = new THREE.MeshLambertMaterial({ color: 0xffd54a, emissive: 0x554100 });
  [-3.2, 3.2].forEach(function (ox) {
    var pillar = new THREE.Mesh(new THREE.BoxGeometry(0.7, 7, 0.7), frameMat);
    pillar.position.set(ox, goal.y + 4, goal.z); scene.add(pillar);
  });
  var top = new THREE.Mesh(new THREE.BoxGeometry(7.1, 0.7, 0.7), frameMat);
  top.position.set(0, goal.y + 7.4, goal.z); scene.add(top);
  var gl = new THREE.PointLight(0xffd54a, 2.2, 26);
  gl.position.set(0, goal.y + 5, goal.z); scene.add(gl);
}
buildLevel();

// ---------------------------------------------------------------- 玩家
var PW = 0.42, PH = 1.7;   // 半宽 / 全高
var player = new THREE.Group();
(function buildPlayer() {
  var body = new THREE.Mesh(new THREE.BoxGeometry(0.8, 1.0, 0.6),
             new THREE.MeshLambertMaterial({ color: 0x34d3a0 }));
  body.position.y = 0.55; player.add(body);
  var head = new THREE.Mesh(new THREE.BoxGeometry(0.62, 0.6, 0.6),
             new THREE.MeshLambertMaterial({ color: 0xffd9a8 }));
  head.position.y = 1.38; player.add(head);
  [-0.52, 0.52].forEach(function (x) {
    var arm = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.75, 0.24),
              new THREE.MeshLambertMaterial({ color: 0x2aa982 }));
    arm.position.set(x, 0.62, 0); arm.name = 'arm'; player.add(arm);
  });
  [-0.22, 0.22].forEach(function (x) {
    var leg = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.65, 0.28),
              new THREE.MeshLambertMaterial({ color: 0x2b6cb0 }));
    leg.position.set(x, -0.28, 0); leg.name = 'leg'; player.add(leg);
  });
})();
scene.add(player);

var P = { x: 0, y: 2, z: 2, vx: 0, vy: 0, vz: 0, onGround: false, coyote: 0, jumpBuf: 0, standing: null };

// ---------------------------------------------------------------- 骷髅
function makeSkeleton() {
  var g = new THREE.Group();
  var skull = new THREE.Mesh(new THREE.BoxGeometry(0.85, 0.8, 0.75), MAT.bone);
  skull.position.y = 1.5; g.add(skull);
  [-0.2, 0.2].forEach(function (x) {
    var e = new THREE.Mesh(new THREE.BoxGeometry(0.17, 0.17, 0.1), MAT.eye);
    e.position.set(x, 1.55, 0.4); g.add(e);
  });
  var jaw = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.18, 0.5), MAT.bone);
  jaw.position.set(0, 1.03, 0.06); g.add(jaw);
  var spine = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.9, 0.2), MAT.bone);
  spine.position.y = 0.55; g.add(spine);
  [0.9, 0.62, 0.34].forEach(function (y, i) {
    var rib = new THREE.Mesh(new THREE.BoxGeometry(0.78 - i * 0.12, 0.13, 0.16), MAT.bone);
    rib.position.y = y; g.add(rib);
  });
  [-0.5, 0.5].forEach(function (x) {
    var arm = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.85, 0.16), MAT.bone);
    arm.position.set(x, 0.72, 0.12); arm.name = 'arm'; g.add(arm);
  });
  [-0.18, 0.18].forEach(function (x) {
    var leg = new THREE.Mesh(new THREE.BoxGeometry(0.17, 0.8, 0.17), MAT.bone);
    leg.position.set(x, -0.3, 0); leg.name = 'leg'; g.add(leg);
  });
  var light = new THREE.PointLight(0xff2b2b, 0.9, 8);
  light.position.set(0, 1.5, 0.5); g.add(light);
  scene.add(g);
  return g;
}

var skeletons = [];
function spawnSkeletons() {
  skeletons.forEach(function (s) { scene.remove(s.obj); });
  skeletons = [];
  var setup = [{ z: -14, x: 0, s: 1.00 }, { z: -19, x: -2.8, s: 0.95 }, { z: -24, x: 2.8, s: 0.90 }];
  setup.forEach(function (c) {
    skeletons.push({ obj: makeSkeleton(), x: c.x, y: 0.9, z: c.z, mul: c.s, bob: Math.random() * 6 });
  });
}

// ---------------------------------------------------------------- 输入
var keys = {};
addEventListener('keydown', function (e) {
  if ([' ', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].indexOf(e.key) >= 0) e.preventDefault();
  // e.repeat = 按住不放时系统自动重发的那些。不过滤的话按住空格就会变成连跳。
  if (e.repeat) return;
  keys[e.code] = true;
  if (e.code === 'Space') {
    if (state === 'menu') startGame();
    else P.jumpBuf = CFG.JUMP_BUFFER;   // 记一次"我要跳"，由 tryJump 在合适的时机兑现
  }
  if (e.code === 'KeyR' && state !== 'menu') resetGame(true);
}, { passive: false });
addEventListener('keyup', function (e) { keys[e.code] = false; });
// 切走再切回来时把按键状态清干净，否则会卡住一个方向
addEventListener('blur', function () { for (var k in keys) keys[k] = false; });
addEventListener('click', function () { if (state === 'menu') startGame(); });

// 自动试玩机器人: 对齐下一块平台 -> 走到边缘 -> 起跳。用来验证每个缺口人能过。
function botInput() {
  var out = { f: true, b: false, l: false, r: false };
  var sorted = platforms.slice().sort(function (a, b) { return a.baseZ - b.baseZ; });
  var next = null;
  for (var i = 0; i < sorted.length; i++) {
    if (sorted[i].baseZ + sorted[i].d / 2 > P.z + 0.6) { next = sorted[i]; break; }
  }
  if (!next) return out;                       // 已经在最后一块，直冲终点
  var cur = P.standing;
  var tx  = next.x;                            // 移动平台取实时 x，会自动追
  // 站在地面时别横移出平台边缘 —— 对齐到台面内就够了，剩下的靠斜跳
  if (cur && P.onGround) {
    tx = Math.max(cur.x - cur.w / 2 + 0.7, Math.min(cur.x + cur.w / 2 - 0.7, tx));
  }
  var dx = tx - P.x;
  if (dx >  0.45) out.r = true;
  if (dx < -0.45) out.l = true;
  // 站在有横杆的平台上就保持连跳 —— 真实玩家也是这么过横杆段的
  if (cur && P.onGround) {
    for (var s = 0; s < sweepers.length; s++) {
      if (Math.abs(sweepers[s].pivot.position.z - P.z) < sweepers[s].len / 2 + 1.5 &&
          Math.abs(sweepers[s].y - P.y) < 2.0) { P.jumpBuf = CFG.JUMP_BUFFER; break; }
    }
  }
  if (cur && P.onGround) {
    var gap    = (next.z - next.d / 2) - (cur.z + cur.d / 2);
    var toEdge = (cur.z + cur.d / 2) - P.z;
    if (gap > 0.2 && toEdge < 1.7) {
      // 目标是移动平台就停在边缘等它摆回来；静态平台直接斜着跳
      if (next.move && Math.abs(next.x - P.x) > 1.5) out.f = false;
      else P.jumpBuf = CFG.JUMP_BUFFER;
    }
  }
  return out;
}

function held() {
  if (BOT) return botInput();
  return {
    f: keys.KeyW || keys.ArrowUp || AUTO_RUN,
    b: keys.KeyS || keys.ArrowDown,
    l: keys.KeyA || keys.ArrowLeft,
    r: keys.KeyD || keys.ArrowRight
  };
}

// ---------------------------------------------------------------- 音效
var AC = null;
function beep(freq, dur, type, vol) {
  try {
    if (!AC) AC = new (window.AudioContext || window.webkitAudioContext)();
    var o = AC.createOscillator(), g = AC.createGain();
    o.type = type || 'square'; o.frequency.value = freq;
    g.gain.setValueAtTime(vol || 0.08, AC.currentTime);
    g.gain.exponentialRampToValueAtTime(0.0001, AC.currentTime + dur);
    o.connect(g); g.connect(AC.destination);
    o.start(); o.stop(AC.currentTime + dur);
  } catch (e) { /* 静音环境下忽略 */ }
}

// ---------------------------------------------------------------- 游戏状态
var state = 'menu';            // menu | play | win | lose
var timeLeft = CFG.TIME_LIMIT;
var coinsGot = 0, elapsed = 0;
var UI = {
  overlay: document.getElementById('overlay'), card: document.getElementById('card'),
  timer: document.getElementById('timer'), coinCount: document.getElementById('coinCount'),
  coinNeed: document.getElementById('coinNeed'), distNum: document.getElementById('distNum'),
  dangerBar: document.getElementById('dangerBar'), progFill: document.getElementById('progFill'),
  vignette: document.getElementById('vignette'), loading: document.getElementById('loading'),
  progLabel: document.getElementById('progLabel')
};
var atGoalShort = 0;   // 站在终点但宝石不够时，差几颗
UI.coinNeed.textContent = CFG.COINS_NEEDED;

function resetGame(autoStart) {
  P.x = 0; P.y = 2; P.z = 2; P.vx = P.vy = P.vz = 0; P.onGround = false; P.standing = null;
  timeLeft = CFG.TIME_LIMIT; elapsed = 0; coinsGot = 0;
  coins.forEach(function (c) { c.got = false; c.mesh.visible = true; c.light.intensity = 1.1; });
  platforms.forEach(function (p) { p.x = p.baseX; p.z = p.baseZ; p.mesh.position.set(p.x, p.y, p.z); });
  spawnSkeletons();
  UI.vignette.style.opacity = 0;
  if (autoStart) { state = 'play'; UI.overlay.classList.add('hidden'); }
}
function startGame() { resetGame(true); beep(660, 0.12, 'triangle', 0.09); }

function endGame(won, reason) {
  state = won ? 'win' : 'lose';
  var used = CFG.TIME_LIMIT - timeLeft;
  var mm = Math.floor(used / 60), ss = Math.floor(used % 60);
  UI.card.innerHTML =
    '<h1 class="' + (won ? 'win' : 'lose') + '">' + (won ? '🏆 通关！' : '💀 GAME OVER') + '</h1>' +
    '<div class="sub">' + reason + '</div>' +
    '<div class="stats">' +
      '<div class="stat"><b>' + coinsGot + '/' + CFG.COINS_NEEDED + '</b><span>宝石</span></div>' +
      '<div class="stat"><b>' + mm + ':' + String(ss).padStart(2, '0') + '</b><span>用时</span></div>' +
      '<div class="stat"><b>' + Math.round(Math.min(100, P.z / LEVEL_END * 100)) + '%</b><span>赛道进度</span></div>' +
    '</div><div class="cta">按 R 再来一次</div>';
  UI.overlay.classList.remove('hidden');
  beep(won ? 880 : 150, won ? 0.5 : 0.7, won ? 'triangle' : 'sawtooth', 0.12);
  if (won) { setTimeout(function () { beep(1180, 0.45, 'triangle', 0.1); }, 170); }
}

// ---------------------------------------------------------------- 碰撞
// 一次按键 = 一次起跳。地面上或土狼时间内才算数，兑现后立刻清空缓冲防止重复触发。
function tryJump() {
  if (P.jumpBuf <= 0) return false;
  if (!P.onGround && P.coyote <= 0) return false;
  P.vy = CFG.JUMP_VEL;
  P.onGround = false; P.coyote = 0; P.jumpBuf = 0; P.standing = null;
  beep(520, 0.1, 'square', 0.06);
  return true;
}

function overlaps(ax, aw, bx, bw) { return Math.abs(ax - bx) < (aw + bw); }

function movePlatforms(t) {
  platforms.forEach(function (p) {
    if (!p.move) { p.dx = 0; p.dz = 0; return; }
    var nx = p.baseX, nz = p.baseZ;
    var off = Math.sin(t * p.move.speed + p.move.phase) * p.move.amp;
    if (p.move.axis === 'x') nx = p.baseX + off; else nz = p.baseZ + off;
    p.dx = nx - p.x; p.dz = nz - p.z;
    p.x = nx; p.z = nz;
    p.mesh.position.set(p.x, p.y, p.z);
  });
}

// 返回玩家脚下最高的可站立平台顶面(仅在下落时判定着陆)
function resolveCollisions(prevBottom) {
  P.onGround = false;
  var landed = null;
  for (var i = 0; i < platforms.length; i++) {
    var p = platforms[i];
    if (!overlaps(P.x, PW, p.x, p.w / 2) || !overlaps(P.z, PW, p.z, p.d / 2)) continue;
    var top = p.y + p.h / 2, bottom = p.y - p.h / 2;
    var feet = P.y, headTop = P.y + PH;
    // 着陆: 下落中且上一帧脚还在顶面之上
    if (P.vy <= 0 && prevBottom >= top - 0.35 && feet <= top + 0.02) {
      if (!landed || top > landed.top) landed = { p: p, top: top };
    } else if (feet < top && headTop > bottom) {
      // 侧向穿插: 沿最小穿透轴推出(防止穿墙进厚平台)
      var penX = (p.w / 2 + PW) - Math.abs(P.x - p.x);
      var penZ = (p.d / 2 + PW) - Math.abs(P.z - p.z);
      if (penX < penZ) { P.x += (P.x > p.x ? penX : -penX); P.vx = 0; }
      else             { P.z += (P.z > p.z ? penZ : -penZ); P.vz = 0; }
    }
  }
  if (landed) {
    P.y = landed.top; P.vy = 0; P.onGround = true; P.coyote = CFG.COYOTE;
    // 站在移动平台上就跟着走
    if (landed.p.move) { P.x += landed.p.dx; P.z += landed.p.dz; }
    P.standing = landed.p;
  } else { P.standing = null; }
}

function checkSweepers(t, dt) {
  var pv = new THREE.Vector3();
  for (var i = 0; i < sweepers.length; i++) {
    var s = sweepers[i];
    s.pivot.rotation.y = t * s.speed;
    // 跳到杆子上方就能躲过去 —— 这是横杆段的核心玩法
    if (P.y > s.y + s.half || P.y + PH < s.y - s.half) continue;
    pv.set(P.x, s.y, P.z);
    s.pivot.worldToLocal(pv);                       // 转到横杆局部坐标
    if (Math.abs(pv.x) < s.len / 2 + PW && Math.abs(pv.z) < 0.28 + PW) {
      // 被扫飞: 沿横杆切线方向给冲量
      var dir = (pv.z >= 0 ? 1 : -1) * (s.speed >= 0 ? 1 : -1);
      var wdir = new THREE.Vector3(0, 0, dir).applyQuaternion(s.pivot.quaternion).normalize();
      P.vx += wdir.x * 13; P.vz += wdir.z * 13; P.vy = Math.max(P.vy, 6);
      P.onGround = false; P.coyote = 0; P.standing = null;   // 已经飞起来了，别再算作站着
      P.x += wdir.x * 0.5 * (dt * 60 / 60); P.z += wdir.z * 0.5;
      beep(200, 0.16, 'sawtooth', 0.1);
    }
  }
}

function checkCoins() {
  for (var i = 0; i < coins.length; i++) {
    var c = coins[i];
    if (c.got) continue;
    var dx = c.mesh.position.x - P.x, dy = c.mesh.position.y - (P.y + 0.85), dz = c.mesh.position.z - P.z;
    if (dx * dx + dy * dy + dz * dz < 2.1 * 2.1) {
      c.got = true; c.mesh.visible = false; c.light.intensity = 0;
      coinsGot++; UI.coinCount.textContent = coinsGot;
      beep(880 + coinsGot * 55, 0.14, 'triangle', 0.09);
    }
  }
}

function updateSkeletons(dt, t) {
  var base = CFG.SKELE_BASE + CFG.SKELE_RAMP * (elapsed / CFG.TIME_LIMIT);
  var nearest = 1e9;
  for (var i = 0; i < skeletons.length; i++) {
    var s = skeletons[i];
    var dx = P.x - s.x, dz = P.z - s.z;
    var len = Math.hypot(dx, dz) || 1;
    // 橡皮筋: 掉队太远就冲刺追回画面内，贴脸时略收，保证"看得见但跑得掉"
    var far = Math.hypot(dx, dz);
    var band = far > CFG.BAND_FAR ? 2.0 : (far < CFG.BAND_NEAR ? 0.82 : 1.0);
    var warm = Math.min(1, elapsed / CFG.WAKE_TIME);   // 开局苏醒，别让新手一愣神就死
    var v = base * s.mul * band * warm;
    s.x += dx / len * v * dt;
    s.z += dz / len * v * dt;
    s.y += (P.y - s.y) * Math.min(1, dt * 5.0);     // 飘着追，缺口拦不住它
    s.bob += dt * 9;
    s.obj.position.set(s.x, s.y + Math.sin(s.bob) * 0.12, s.z);
    s.obj.rotation.y = Math.atan2(dx, dz);
    // 手脚摆动
    s.obj.children.forEach(function (c) {
      if (c.name === 'leg') c.rotation.x = Math.sin(s.bob) * 0.7 * (c.position.x > 0 ? 1 : -1);
      if (c.name === 'arm') c.rotation.x = Math.sin(s.bob + Math.PI) * 0.55 * (c.position.x > 0 ? 1 : -1);
    });
    // 贴到镜头上就藏起来 —— 否则一只骷髅会糊满整个屏幕挡住赛道
    s.obj.visible = s.obj.position.distanceTo(camera.position) > 4.5;

    var d = Math.hypot(P.x - s.x, P.z - s.z);
    if (d < nearest) nearest = d;
    if (d < CFG.CATCH_DIST && Math.abs(P.y - s.y) < 2.2) {
      endGame(false, '骷髅抓住你了！下次别停下来 —— 一直往前跑。');
      return;
    }
  }
  UI.distNum.textContent = nearest > 900 ? '--' : nearest.toFixed(1);
  var danger = Math.max(0, Math.min(1, 1 - (nearest - CFG.CATCH_DIST) / 18));
  UI.dangerBar.style.width = (danger * 100).toFixed(0) + '%';
  UI.vignette.style.opacity = danger > 0.6 ? ((danger - 0.6) / 0.4 * 0.85).toFixed(2) : 0;
}

// ---------------------------------------------------------------- 主循环
var clock = new THREE.Clock();
var camPos = new THREE.Vector3(0, 6, -8);
var walkPhase = 0;

function update(dt, t) {
  movePlatforms(t);

  if (state === 'play') {
    // 计时
    elapsed += dt; timeLeft -= dt;
    if (timeLeft <= 0) { timeLeft = 0; endGame(false, '时间到！5 分钟没能冲到终点。'); }

    // 水平移动(摄像机固定朝 +Z，所以就是世界轴向，小朋友最好上手)
    var k = held(), ax = 0, az = 0;
    if (k.f) az += 1; if (k.b) az -= 1;
    if (k.l) ax -= 1; if (k.r) ax += 1;
    var mag = Math.hypot(ax, az);
    if (mag > 0) { ax /= mag; az /= mag; }
    var ctrl = P.onGround ? 1 : CFG.AIR_CONTROL;
    var targetVx = ax * CFG.MOVE_SPEED, targetVz = az * CFG.MOVE_SPEED;
    var accel = (P.onGround ? 14 : 9) * ctrl;
    P.vx += (targetVx - P.vx) * Math.min(1, accel * dt);
    P.vz += (targetVz - P.vz) * Math.min(1, accel * dt);

    // 跳跃(含土狼时间 + 输入缓冲)。计时先走，再试着兑现这次跳。
    P.coyote -= dt; P.jumpBuf -= dt;
    tryJump();

    // 重力 + 积分
    P.vy += CFG.GRAVITY * dt;
    var prevBottom = P.y;
    P.x += P.vx * dt; P.z += P.vz * dt; P.y += P.vy * dt;

    resolveCollisions(prevBottom);
    // 刚落地的这一帧就把缓冲的跳兑现掉，不然要等下一帧，按键会像"丢了"
    if (tryJump()) P.y += P.vy * dt;
    checkSweepers(t, dt);
    checkCoins();
    if (state === 'play') updateSkeletons(dt, t);

    // 掉出地图
    if (P.y < CFG.FALL_DEATH_Y && state === 'play') {
      endGame(false, '你掉下去了！看准落点再起跳。');
    }

    // 终点判定
    if (state === 'play' && Math.hypot(P.x - goal.x, P.z - goal.z) < goal.r && P.y > goal.y) {
      if (coinsGot >= CFG.COINS_NEEDED) {
        endGame(true, '你甩掉了骷髅，集齐宝石冲过终点 —— 干得漂亮，Michael！');
        atGoalShort = 0;
      } else {
        atGoalShort = CFG.COINS_NEEDED - coinsGot;
      }
    }

    // HUD
    var mm = Math.floor(timeLeft / 60), ss = Math.floor(timeLeft % 60);
    UI.timer.textContent = mm + ':' + String(ss).padStart(2, '0');
    UI.timer.classList.toggle('warn', timeLeft < 30);
    UI.progFill.style.width = Math.max(0, Math.min(100, P.z / LEVEL_END * 100)).toFixed(1) + '%';
    UI.progLabel.textContent = atGoalShort > 0
      ? '🏁 还差 ' + atGoalShort + ' 颗宝石才能通关！'
      : '赛道进度';
    atGoalShort = 0;
  }

  // 玩家模型
  player.position.set(P.x, P.y, P.z);
  var spd = Math.hypot(P.vx, P.vz);
  if (spd > 0.6) player.rotation.y = Math.atan2(P.vx, P.vz);
  walkPhase += dt * Math.min(spd, 14) * 1.5;
  player.children.forEach(function (c) {
    if (c.name === 'leg') c.rotation.x = P.onGround ? Math.sin(walkPhase) * 0.8 * (c.position.x > 0 ? 1 : -1) : 0.35;
    if (c.name === 'arm') c.rotation.x = P.onGround ? Math.sin(walkPhase + Math.PI) * 0.6 * (c.position.x > 0 ? 1 : -1) : -1.9;
  });

  // 宝石旋转
  for (var i = 0; i < coins.length; i++) {
    if (coins[i].got) continue;
    coins[i].mesh.rotation.y += dt * 2.6;
    coins[i].mesh.position.y += Math.sin(t * 3 + i) * dt * 0.35;
    coins[i].light.position.copy(coins[i].mesh.position);
  }

  // 摄像机: 玩家后上方平滑跟随，始终朝赛道方向
  var want = new THREE.Vector3(P.x * 0.55, P.y + 6.6, P.z - 14.0);
  camPos.lerp(want, Math.min(1, dt * 4.5));
  camera.position.copy(camPos);
  camera.lookAt(P.x * 0.6, P.y + 1.4, P.z + 6);
}

function loop() {
  requestAnimationFrame(loop);
  var dt = Math.min(clock.getDelta(), 1 / 20);   // 卡顿时钳位，防止穿模
  update(dt, clock.elapsedTime);
  renderer.render(scene, camera);
}

resetGame(false);
UI.loading.classList.add('hidden');

// 快进钩子: ?ff=3 先模拟 3 秒(headless 截图用)
if (FF > 0) {
  state = 'play'; UI.overlay.classList.add('hidden');
  var step = 1 / 60, simT = 0;
  while (simT < FF) { update(step, simT); simT += step; }
  clock.start();
}
loop();
// 关卡自检: 把每个缺口的真实跨度跟跳跃射程比一比(?audit=1 时输出到页面)
function auditLevel() {
  var air   = 2 * CFG.JUMP_VEL / -CFG.GRAVITY;          // 滞空时间
  var reach = CFG.MOVE_SPEED * air;                     // 水平射程
  var sorted = platforms.slice().sort(function (a, b) { return a.baseZ - b.baseZ; });
  var rows = [], worst = 0;
  for (var i = 1; i < sorted.length; i++) {
    var prev = sorted[i - 1], cur = sorted[i];
    var gapZ = (cur.baseZ - cur.d / 2) - (prev.baseZ + prev.d / 2);
    if (gapZ <= 0.05) continue;                         // 相邻/重叠，不是缺口
    // 横向错开时要按斜边算，移动平台按最坏相位(摆到最远)算
    var dx = Math.abs(cur.baseX - prev.baseX)
           + (cur.move ? cur.move.amp : 0) + (prev.move ? prev.move.amp : 0);
    var lateral = Math.max(0, dx - (cur.w / 2 + prev.w / 2));
    var span = Math.hypot(gapZ, lateral);
    var rise = cur.y - prev.y;
    rows.push({ z: cur.baseZ.toFixed(1), gapZ: gapZ.toFixed(2), span: span.toFixed(2),
                rise: rise.toFixed(2), ok: span <= reach - 0.8 });
    if (span > worst) worst = span;
  }
  return { reach: reach, air: air, worst: worst, rows: rows,
           coinsTotal: coins.length, coinsNeeded: CFG.COINS_NEEDED, levelEnd: LEVEL_END,
           allOk: rows.every(function (r) { return r.ok; }) };
}

if (params.get('audit') === '1') {
  var a = auditLevel();
  var txt = 'REACH=' + a.reach.toFixed(2) + ' AIR=' + a.air.toFixed(3) +
            ' WORST=' + a.worst.toFixed(2) + ' ALLOK=' + a.allOk +
            ' COINS=' + a.coinsTotal + '/' + a.coinsNeeded +
            ' END=' + a.levelEnd.toFixed(1) + ' PLATFORMS=' + platforms.length + '\n' +
            'RUN: state=' + state + ' z=' + P.z.toFixed(1) +
            ' progress=' + (P.z / LEVEL_END * 100).toFixed(1) + '%' +
            ' coins=' + coinsGot + ' timeLeft=' + timeLeft.toFixed(1) +
            ' nearestSkel=' + (skeletons.length
                ? Math.min.apply(null, skeletons.map(function (s) {
                    return Math.hypot(P.x - s.x, P.z - s.z); })).toFixed(2) : 'n/a') + '\n' +
            a.rows.map(function (r) {
              return '  z=' + r.z + ' gapZ=' + r.gapZ + ' span=' + r.span +
                     ' rise=' + r.rise + ' ' + (r.ok ? 'OK' : '!!TOO FAR!!');
            }).join('\n');
  var pre = document.createElement('pre');
  pre.id = 'auditOut';
  pre.style.cssText = 'position:fixed;inset:0;z-index:99;background:#000;color:#0f0;font-size:13px;padding:16px;white-space:pre;overflow:auto';
  pre.textContent = txt;
  document.body.appendChild(pre);
}

window.__game = { P: P, get state() { return state; }, get coins() { return coinsGot; },
                  CFG: CFG, LEVEL_END: LEVEL_END, platforms: platforms, audit: auditLevel };
})();
