# Kehan · Star Rescue

2026.09.22-r2 · GitHub 评审版 / GitHub review release

解压后打开 Start.command（Mac）或 Start.cmd（Windows）。需已安装 Node.js，不自动联网安装。也可终端 `node server.mjs`，浏览器打开 http://127.0.0.1:18922/ 。

Extract, then run Start.command (Mac) or Start.cmd (Windows). Requires an existing Node.js installation; no dependency installation or internet is needed. Alternatively run `node server.mjs` and open http://127.0.0.1:18922/ .

端口占用：关闭之前的同类审阅服务，或自行指定空闲 PORT。不要杀死不明进程。
If the port is busy, use an available PORT or stop your own previous review server. Never terminate an unknown process.

完整游戏单人可玩。Harrison/Zavier 使用两名电脑队友。按游戏内说明操作；HUB 按钮返回这个离线说明页。完整 HUB 可通过下面的 GitHub Pages 链接查看。
Single-player gameplay is included; the Harrison/Zavier game supplies two bot buddies. The HUB button returns to this offline guide. The full HUB is available through the GitHub Pages link below.

原始源码、旧候选、课堂原音、克隆素材、私密账本和 node_modules 均不包含。GitHub 发布版；原课堂项目未删除。
No old candidates, original classroom audio, clone assets, private ledger or node_modules. GitHub release; original classroom projects remain untouched.

Online HUB: https://sydneygemstone-sudo.github.io/student-works/classroom-2026-09-22/kehan-hub.html
