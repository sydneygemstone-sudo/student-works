import http from 'node:http';import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';
const here=path.dirname(fileURLToPath(import.meta.url));const root=fs.existsSync(path.join(here,'public'))?path.join(here,'public'):here;
const port=Number(process.env.PORT||18922),host=process.env.HOST||'127.0.0.1';
const mime={'.html':'text/html;charset=utf-8','.js':'text/javascript;charset=utf-8','.mjs':'text/javascript;charset=utf-8','.css':'text/css;charset=utf-8','.json':'application/json;charset=utf-8','.png':'image/png','.svg':'image/svg+xml','.wav':'audio/wav','.zip':'application/zip'};
http.createServer((req,res)=>{let url;try{url=decodeURIComponent(new URL(req.url,'http://local').pathname);}catch{return res.writeHead(400).end();}
let f=path.resolve(root,'.'+url);if(f!==root&&!f.startsWith(root+path.sep))return res.writeHead(403).end();
try{if(fs.statSync(f).isDirectory())f=path.join(f,'index.html');if(!fs.realpathSync(f).startsWith(fs.realpathSync(root)+path.sep))return res.writeHead(403).end();}catch{return res.writeHead(404).end();}
fs.readFile(f,(e,b)=>{if(e)return res.writeHead(404).end();res.writeHead(200,{'Content-Type':mime[path.extname(f)]||'application/octet-stream','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end(b);});}).listen(port,host,()=>console.log(`Classroom review: http://${host}:${port}/`));
