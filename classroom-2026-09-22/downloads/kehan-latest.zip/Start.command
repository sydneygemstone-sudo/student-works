#!/bin/zsh
set -eu
HERE="${0:A:h}"
NODE="$(command -v node || true)"
if [[ -z "$NODE" && -x /opt/homebrew/bin/node ]]; then NODE=/opt/homebrew/bin/node; fi
if [[ -z "$NODE" ]]; then print "Please install Node.js first. No dependencies are downloaded by this launcher."; read; exit 1; fi
PORT="${PORT:-18941}"
print "Open http://127.0.0.1:$PORT/ after the server starts."
export PORT
exec "$NODE" "$HERE/server.mjs"
