#!/bin/sh
cd "$(dirname "$0")" || exit 1
NODE="$(command -v node || true)"
[ -n "$NODE" ] || NODE=/opt/homebrew/bin/node
if [ ! -x "$NODE" ]; then echo "Node.js is required / 需要预先安装 Node.js"; exit 1; fi
open "http://127.0.0.1:18922/"
exec "$NODE" server.mjs
