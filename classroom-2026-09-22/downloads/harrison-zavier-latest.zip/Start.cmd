@echo off
where node >nul 2>nul
if errorlevel 1 (
 echo Please install Node.js first.
 pause
 exit /b 1
)
node "%~dp0server.mjs"
pause
